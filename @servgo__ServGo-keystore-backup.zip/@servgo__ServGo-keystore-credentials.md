# Android Keystore Credentials

These credentials are used in conjunction with your Android keystore file to sign your app for distribution. 

## Credential Values

- Android keystore password: 9540040448
- Android key alias: serv-go
- Android key password: null
      